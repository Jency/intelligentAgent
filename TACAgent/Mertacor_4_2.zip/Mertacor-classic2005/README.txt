
Agent Mertacor - TAC 2005 - Classic game - 1st Place winner
============================================================
This is the binary distribution of the MerTACor agent as 
ran in the 2005 TAC-classic finals and ranked in the 1st place. 

The agent adheres to the atest specifications 
implemented in version TAC Classic Java Server 1.0 beta 11. 
It requires Java 1.4.2 or above and has been tested in both Windows 
and Linux operating systems. 

This release includes (in the lib directory) the lp_solve third party 
library version 5.1, which is freely available at http://groups.yahoo.com/group/lp_solve/. 

In the same directory you will also find the TAC agentware binaries, 
freely available at the official TAC site: http://www.sics.se/tac

To run Mertacor:

1) Modify the agent.conf file in the config directory according to your 
preferences. The default configuration will allow this agent to run in 
tac1 server with the name Mertacor-bin.

2) Change to the root directory and type "run" in a command prompt (windows) 
or a terminal window (linux). 

During its execution, the agent will create log files in the root directory, 
as well as in directory "games". Additional information will be also stored 
in the "stats" directory. Please do not delete this directory in order to 
allow smooth agent execution. 

This release, as well as the implementation details of the Mertacor agent can 
be found at Mertacor's web site: 

http://danae.ee.auth.gr/MertacorWeb/

For any question, please send an email to mertacor@danae.ee.auth.gr

The Mertacor development team: 

Panos Toulis, 
Dionysis Kehagias, 
Pericles Mitkas.

Aristotle University of Thessaloniki, 
Department of Electrical and Computer Engineering,
Thessaloniki, Greece

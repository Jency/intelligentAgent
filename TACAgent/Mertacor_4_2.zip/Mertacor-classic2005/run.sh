#!/bin/bash
java -Djava.library.path=./lib/linux -jar bin/mertacor.jar -config config/agent.conf

